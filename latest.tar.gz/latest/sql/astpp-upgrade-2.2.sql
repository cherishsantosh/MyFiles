update timezone SET gmtzone="(GMT+02:00) Harare, Pretoria" where id=36;
UPDATE `system` SET `value` = '2.2' WHERE `system`.`name` ='version';	