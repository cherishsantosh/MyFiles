<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['admin_email']='info@astpp.com';
$config['size_number']='10';	
?>
