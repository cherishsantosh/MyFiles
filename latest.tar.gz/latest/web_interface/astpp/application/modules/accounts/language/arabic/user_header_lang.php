<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$lang['header.home']='Home';
$lang['header.accounts']='Accounts';
$lang['header.account_detail']='Account Detail';
$lang['header.invoice_detail']='Invoice Detail';
$lang['header.my_account_cdr']='My Account CDR';
$lang['header.payment_detail']='Payment Detail';

$lang['header.services']='Services';
$lang['header.cc']='Calling Cards';
$lang['header.my_cccard']='My CallingCard';
$lang['header.my_cccard_cdr']='My CallingCard CDR';

$lang['header.did']='DIDs';
$lang['header.manage_did']='Manage DIDs';

$lang['header.mapping']='Mapping';
$lang['header.ani_mapping']='ANI Mapping';

$lang['header.rates']='Rates';


?>
