 
<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['CHARGES.DESCRIPTION']='Description';
$lang['CHARGES.RATE_GROUP']='Rate Group';
$lang['CHARGES.RATE']='Rate';
$lang['CHARGES.CYCLE']='Cycle';
$lang['CHARGES.CHARGE']='Charge';
$lang['CHARGES.ACCOUNT_STATUS']='Account Status';
$lang['CHARGES.BILLING_SCHEDULE']='Billing Schedule';
$lang['CHARGES.COST']='Cost';
$lang['CHARGES.STATUS']='Status';
$lang['CHARGES.CREATE_CHARGES']='Charges';
$lang['CHARGES.DELETE']='Delete';
$lang['CHARGES.REFRESH']='Refresh';
$lang['CHARGES.ACTION']='Action';
$lang['CHARGES.CREATE_CHARGES']='Create Charges';
$lang['CHARGES.PERIODIC_CHARGELIST']='Periodic Charges List';
$lang['CHARGES.CHARGES_LIST']='Charges List';
$lang['CHARGES.SEARCH']='Search';
$lang['CHARGES.ADD_CHARGES']='Add Charges';
$lang['CHARGES.CARD_INFO']='Card Information';
$lang['CHARGES.SEARCH_PERIODIC_CHARGES']='Search Periodic Charges';

$lang['CHARGES.EDIT_CHARGES']='Edit Charges';
$lang['CHARGES.ACCOUNT_NUM']='Account Number';

?>
