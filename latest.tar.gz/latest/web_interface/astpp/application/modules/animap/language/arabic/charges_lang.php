 
<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['CHARGES.DESCRIPTION']='Descripción';
$lang['CHARGES.RATE_GROUP']='Cambio de grupo';
$lang['CHARGES.RATE']='Velocidad';
$lang['CHARGES.CYCLE']='Ciclo';
$lang['CHARGES.CHARGE']='Cargo';
$lang['CHARGES.ACCOUNT_STATUS']='Estado de la cuenta';
$lang['CHARGES.BILLING_SCHEDULE']='Segundo facturación';
$lang['CHARGES.COST']='Costo';
$lang['CHARGES.STATUS']='Estado';
$lang['CHARGES.CREATE_CHARGES']='Crear Cargos';
$lang['CHARGES.DELETE']='Borrar';
$lang['CHARGES.REFRESH']='Refrescar';
$lang['CHARGES.ACTION']='Accion';
$lang['CHARGES.CREATE_CHARGES']='Crear cargos';
$lang['CHARGES.PERIODIC_CHARGELIST']='Lista de los honorarios periódicos';
$lang['CHARGES.CHARGES_LIST']='Lista de cargos';
$lang['CHARGES.SEARCH']='Búsqueda';
$lang['CHARGES.ADD_CHARGES']='Añadir Cargos';
$lang['CHARGES.EDIT_CHARGES']='Editar cargos';
$lang['CHARGES.CARD_INFO']='Información de la tarjeta';
$lang['CHARGES.SEARCH_PERIODIC_CHARGES']='Buscar en cargos periódicos';
?>