<? extend('master.php') ?>	
<? startblock('page-title') ?>       
<? endblock() ?>    
<? startblock('content') ?>  
<section class="slice color-three">
	<div class="w-section inverse no-padding">
    	<div class="container">
        	<div class="row">
                <div class="col-md-12">      
                       
                </div>  
            </div>
        </div>
    </div>
</section>
<? endblock() ?>
<? startblock('sidebar') ?>
<? endblock() ?>
<? end_extend() ?>  
