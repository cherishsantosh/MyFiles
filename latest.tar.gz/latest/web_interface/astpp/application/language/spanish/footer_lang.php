<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$lang['FOOTER.FOOTER']='Copyright © 2003 - 2012. ASTPP - Open Source Solución de Facturación VOIP. Todos los Derechos Reservados.';
?>
