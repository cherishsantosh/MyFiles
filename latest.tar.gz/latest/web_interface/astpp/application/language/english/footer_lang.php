<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$lang['FOOTER.FOOTER']='Copyright &copy; 2003 - 2012. ASTPP - Open Source VOIP Billing Solution. All Rights Reserved.';
?>
